#include <stdio.h>

int decode2(int x, int y, int z){
	int left = ((y-z) << 31) >> 31;
	int right = (y - z)*x;
	int sol = left^right;

	return sol;
 }

 int main(void){
 	printf("%d\n", decode2(1, 2, 4));

 	printf("%d\n", decode2(-4, -8, -12));

 }